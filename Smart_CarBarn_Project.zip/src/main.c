#include <stdio.h>
#include "camera.h"		//jpeg头文件
#include "font.h"		//字库头文件
#include "yuyv.h"		//摄像头头文件
#include "rfid.h"		//RFID头文件
#include "voice_play.h"	//语音播报模块

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <linux/input.h>		//输入子系统的头文件

static struct timeval timeout;

/*智能车库主函数*/
int main()
{	
	int ret, i;
	int fd;
	char print_word[64];
	
	Init_Font();		//字库初始化
	
	//1,显示主界面	--> 准备一张800*480的jpg图片
	show_jpg("zhujiemian.jpg", 0, 0);
	
	system("madplay hyjr.mp3");
	
	//3s之后进入实时监控
	sleep(3);
	pthread_t tid;
	pthread_create(&tid, NULL, get_picture, NULL);		//实时监控
	
	fd = open(DEV_PATH, O_RDWR | O_NOCTTY | O_NONBLOCK);		//第一个4针串口
	if (fd < 0)
	{
		fprintf(stderr, "Open Gec6818_ttySAC1 fail!\n");
		return -1;
	}
	/*初始化串口*/
	init_tty(fd);
	
	while(1)	//循环检测RFID卡
	{
		timeout.tv_sec = 1;
		timeout.tv_usec = 0;
		/*请求天线范围的卡*/
		if ( PiccRequest(fd) )
		{
			//printf("The request failed!\n");
			//close(fd);
			//return -1;
		}
		usleep(30*1000);
		/*进行防碰撞，获取天线范围内最大的ID*/
		if( PiccAnticoll(fd) )
		{
			//printf("Couldn't get card-id!\n");
			//close(fd);
			//return -1;
		}
		if(ID != 0)	//循环检测是否读取到卡号，如果读取到就打印一次，没有读取到就不打印
		{
			//抓拍图片
			
			Catch_Pic = 1;
			sleep(3);
			ID = 0;
		}
		
		sleep(1);
	}
	
	UnInit_Font();		//字库资源释放
	
	return 0;
}


